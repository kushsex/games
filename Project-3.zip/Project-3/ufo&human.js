//Robert Hughes, 4/17/2021, ufo&human.js, This is the main Javascript file that ufomain.html calls for the player and target objects.
	
	function Human() {
				tHuman = new Sprite (scene, "Man3.png", 40, 40);
				tHuman.setSpeed(5);
				tHuman.run = function() {
					newDir = (Math.random() * 90) - 45;
					this.changeAngleBy(newDir);
			}//end run
			tHuman.reset = function() {
				newX = Math.random() * this.cWidth;
				newY = Math.random() * this.cHeight;
				this.setPosition(newX, newY);
			}//end reset function
			tHuman.reset();
			return tHuman;
		} //end human
		
		function Humantwo() {
				tHumantwo = new Sprite (scene, "Man3.png", 40, 40);
				tHumantwo.setSpeed(5);
				tHumantwo.run = function() {
					newDir = (Math.random() * 90) - 45;
					this.changeAngleBy(newDir);
			}//end run
			tHumantwo.reset = function() {
				newX = Math.random() * this.cWidth;
				newY = Math.random() * this.cHeight;
				this.setPosition(newX, newY);
			}//end reset function
			tHumantwo.reset();
			return tHumantwo;
		} //end HumanTwo
		
				function Humanthree() {
				tHumanthree = new Sprite (scene, "Man3.png", 40, 40);
				tHumanthree.setSpeed(5);
				tHumanthree.run = function() {
					newDir = (Math.random() * 90) - 45;
					this.changeAngleBy(newDir);
			}//end run
			tHumanthree.reset = function() {
				newX = Math.random() * this.cWidth;
				newY = Math.random() * this.cHeight;
				this.setPosition(newX, newY);
			}//end reset function
			tHumanthree.reset();
			return tHumanthree;
		} //end Humanthree
		
		
	function Ufo() {
			tUfo = new Sprite (scene, "ufo.png", 80, 80);
			tUfo.maxSpeed = 10;
			tUfo.minSpeed = -3;
			tUfo.setSpeed(0);
			tUfo.setAngle(0);
			tUfo.checkKeys = function() {
				if (keysDown [K_LEFT]) {
					this.changeAngleBy(-5);
				}//end if left
				if (keysDown [K_RIGHT]) {
					this.changeAngleBy(5);
				}//end if right
				if (keysDown [K_UP]) {
					this.changeSpeedBy(1);
					if (this.speed > this.maxSpeed){
						this.setSpeed(this.maxSpeed);
					}//end if max speed up
				}//end if up
				if (keysDown [K_DOWN]) {
					this.changeSpeedBy(-1);
					if (this.speed < this.minSpeed){
						this.setSpeed(this.minSpeed);
					}//end if max speed up
				}//end if up
			}//end check keys function
			return tUfo;
		}//end Ufo